#include <stdio.h>
#include <string.h>

int main(){
  char input[140];
  printf("Enter the post (up to 140 characters):"); 
  fgets(input, sizeof(input), stdin); 

  if (strlen(input) > 140 || input[strlen(input)-1] !='\n'){ 
   
    printf("Rejected\n"); 
  }
  if (strlen(input) <= 140 && input[strlen(input)-1] =='\n'){ 
    printf("Posted"); 
  }

  return 0;
}
